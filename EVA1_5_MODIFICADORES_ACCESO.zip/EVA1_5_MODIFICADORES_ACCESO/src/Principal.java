/*
 *Continuacion de clases y objetos 
 *modificadores de acceso para atributos,metosoa y classes
 */
/*
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    public static void main(String[] args) {
        // TODO code application logic here
        Banco bBank = new Banco();
        bBank.sNombre = "Daniel Yañez";
        bBank.dSaldoCuenta = 500;
        System.out.println("Cliente: " + bBank.sNombre);
        System.out.println("Saldo: " + bBank.dSaldoCuenta);
        
        bBank.dSaldoCuenta = 0;
        System.out.println("Cliente: " + bBank.sNombre);
        System.out.println("Saldo: " + bBank.dSaldoCuenta);
    }
    
}
class Banco{
    // En general, los atributos de una clase son privados
     String sNombre;
     double dSaldoCuenta;

}