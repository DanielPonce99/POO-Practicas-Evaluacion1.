/*
 * Demostracion de nuveles de acceso
 * public, private, protected, default
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {
    public int iPublico = 10;
    private int iPrivado = 20;
    protected int iProtejido = 30;
    int idefault = 40;

    
    public static void main(String[] args) {
        // TODO code application logic here
        Principal pPrincipal = new Principal();
        System.out.println(pPrincipal.iPublico);
        System.out.println(pPrincipal.iPrivado);
        System.out.println(pPrincipal.iProtejido);
        System.out.println(pPrincipal.idefault);
        
        Default dDefault = new Default();
        System.out.println(dDefault.iPublico);
        System.out.println(dDefault.iProtejido);
        System.out.println(dDefault.idefault);
        
        Secundaria sSecundaria = new Secundaria();
        System.out.println(sSecundaria.iPublico);
        System.out.println(sSecundaria.iProtejido);
        System.out.println(sSecundaria.idefault);
        
        DefaultSecond dDefaultSecond = new DefaultSecond();
        System.out.println(dDefaultSecond.iPublico);
        System.out.println(dDefaultSecond.iProtejido);
        System.out.println(dDefaultSecond.idefault);
        
    }
    
}
class Default{
    public int iPublico = 10;
    private int iPrivado = 20;
    protected int iProtejido = 30;
    int idefault = 40; 
}