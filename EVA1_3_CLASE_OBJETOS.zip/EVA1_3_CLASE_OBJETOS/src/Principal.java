/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Crear objetos de clase: Instanciacion
        //Declarar Variable
        //Nombre de la clase nombre del objeto
        Principal ObjetoPpal; // Declarando objeto
        //Asignacion de memoria(Creacon de la instancia)
        ObjetoPpal = new Principal();
        System.out.println("El objeto tiene: " + ObjetoPpal);
        /////
        Principal PObj2 = new Principal();// Instanciacion de una sola vez
        
        
    }
    //Clase sin estado(variables) 
    class Simple{
    }
    
}
