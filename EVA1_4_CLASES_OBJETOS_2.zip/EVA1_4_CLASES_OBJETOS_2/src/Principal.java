
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //INSTANCIAR LA CLASE PERSONA
        //1.- los objetos son identificadores (variables)
        Persona pPersona1;
        Persona pPersona2;//Declaracion
        //INSTANCIA= ASIGNAR VALOR(MEMORIA) -> new
        pPersona1 = new Persona(); // El objeto existe
        //Capturar Datos
        System.out.println("Introduce tu nombre: ");
        Scanner Captu = new Scanner(System.in);
        pPersona1.Nombre= Captu.nextLine();
        System.out.println(pPersona1.Nombre); // AQUI SI PODEMOS
       
        
        pPersona2 = new Persona();
        System.out.println("Introduce tu Nombre: ");
        pPersona2.Nombre= Captu.nextLine();
        System.out.println("Introduce tu Apellido: ");
        pPersona2.Apellido = Captu.nextLine();
        System.out.println(pPersona2.Apellido);
        System.out.println("Introduce tu Genero: ");
        pPersona2.Genero = Captu.nextLine();
        System.out.println("Introduce tu RFC: ");
        pPersona2.RFC = Captu.nextLine();
        System.out.println("Introduce tu Estado Civil: ");
        pPersona2.EstadoCivil= Captu.nextLine();
        System.out.println("Introduce Estado de Nacimiento: ");
        pPersona2.EstadoNacimiento= Captu.nextInt();
        System.out.println("Introduce tu Edad: ");
        pPersona2.Edad = Captu.nextInt();
        System.out.println("Introduce la Ciudad en la que vives: ");
        System.out.println("Tu nombre completo es: " + pPersona2.Nombre + " " + pPersona2.Apellido);
        pPersona2.imprimeNombreCompleto();
        
    }
    
}
class Persona{
    String Nombre;
    String Apellido;
    String RFC;
    String Genero;
    String Ciudad;
    String EstadoCivil;
    int Edad;
    int EstadoNacimiento;
    //COMPORTAMIENTO DE LA CLASE 
    //Metodos y/o funciones
    //Nivel de acceso | Valor de retorno | Nombre(Argumentos)
    public void imprimeNombreCompleto(){
        System.out.println(Nombre + " " + Apellido);

    }
    
}
