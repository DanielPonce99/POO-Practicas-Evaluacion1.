/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

   
    public static void main(String[] args) {
      System.out.println("Hola Mundo Cruel");//Nos permite imprimir en consola
      System.out.println("Programacion Orientada a Objetos");
    }
    
}
