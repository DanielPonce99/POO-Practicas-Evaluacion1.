
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
              // TODO code application logic here
        //Llamada a Función
        saludaUsuario();
        //Ejemplo 2
        String sNombre= capturaNombre();
        imprimeSaludo(sNombre);
        //simplificado
        imprimeSaludo(capturaNombre());
    }
    // Necesitamos una función que salude
    public static void saludaUsuario(){
     Scanner input = new Scanner (System.in);
        System.out.println("Cual es tu nombre ");
        String sCade = input.nextLine();
        System.out.println("Hola "+sCade);
        
        
        
        
    }
    //Saludo separado
    // Función para capturar el nombre del usuario y regresarlo
    public static String capturaNombre(){
    
     Scanner input = new Scanner (System.in);
        System.out.println("Cual es tu nombre ");
        String sCade = input.nextLine();
       return sCade;
    }
    
    //Función para imprimir un saludo
    public static  void imprimeSaludo(String Nombre){
        System.out.println("Hola " +Nombre);
    
    }
    
    public static void recursvida(){
        System.out.println("Ups");
     //Recursvida();
     saludaUsuario();
    }
    
}
