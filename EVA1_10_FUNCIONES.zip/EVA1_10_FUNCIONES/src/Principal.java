
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner Captu =new Scanner(System.in);
        double Base, Altura; //Declaracion de variables
        System.out.println("Ingresa la base del trinagulo");
        Base= Captu.nextDouble();
        System.out.println("Ingresa la altura");
        Altura= Captu.nextDouble();
        double Area=calculaArea(Base, Altura);//Llama la funcion
        System.out.println("El area es: "+Area);
    }
    //Definiendo una función area
    //Modificasdor de acceso || Tipo de retorno || Nombre (varables de entrada)
    public static double calculaArea(double Base, double Altura)
    {
        
        double Area;
        Area=(Base*Altura)/2;//Operacion de la funcion
        return Area;
    }
    
    
}
