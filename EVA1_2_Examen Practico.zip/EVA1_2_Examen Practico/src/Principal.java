
import java.util.Scanner;


/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                Scanner sCaptu = new Scanner(System.in);//Variable para capturar el teclado
        // Scanner es una clase para facilitar la lectura del teclado
        //System.in es la entrada de perifericos de java
       System.out.println("Introduce el numero del (1 - 12)");
        
        int iCaptuMes = sCaptu.nextInt();//Lo que el usuario teclee lo convertimos a entero
        
        switch(iCaptuMes){
            case 1:
                System.out.println("Enero");
                break;
                
            case 2:
                System.out.println("Febrero");
                break;
                
            case 3:
                System.out.println("Marzo");
                break;
                
                case 4:
                System.out.println("Abril");
                break;
                
                case 5:
                System.out.println("Mayo");
                break;
                
                case 6:
                System.out.println("Junio");
                break;
                
                case 7:
                System.out.println("Julio");
                break;
                
                case 8:
                System.out.println("Agosto");
                break;
                
                case 9:
                System.out.println("Septiembre");
                break;
                
                case 10:
                System.out.println("Octubre");
                break;
                
                case 11:
                System.out.println("Noviembre");
                break;
                
                case 12:
                System.out.println("Diciembre");
                break;
                
                default:
                    System.out.println("No existe el mes");
    }
    }
    }
