
import MisClases.Banco;
import MisClases.MejorBanco;

/*
 * Clase banco para ejemplificar uso de atrinutos
 * metodos y modificadores de acceso
 */

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class Principal {

    
    public static void main(String[] args) {
        Banco bMicuenta = new Banco();
        bMicuenta.Nombre="Daniel Yañez";
        bMicuenta.Saldo=500;
        System.out.println("INFRMACION DE LA CUENTA");
        System.out.println("Titular: " + bMicuenta.Nombre);
        System.out.println("Saldo: " + bMicuenta.Saldo);
        // Me robaron el dinero me cambio de banco
        
        MejorBanco bMejorcuenta = new MejorBanco();
        bMejorcuenta.setNombre("Daniel Yañez");
        bMejorcuenta.setSaldo(500);
        System.out.println("Mi nueva cuenta en un mejor banco");
        System.out.println("Titular: " + bMejorcuenta.getNombre());
        System.out.println("Saldo: " + bMejorcuenta.getSaldo());
      
    }
    
}
