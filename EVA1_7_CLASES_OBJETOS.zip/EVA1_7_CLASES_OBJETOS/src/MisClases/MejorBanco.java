/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MisClases;

/**
 *
 * @author Daniel Elias Yañez Ponce 18550346
 */
public class MejorBanco {
    //Los Atributos de la clase siempre tienen que ser privados
    private String Nombre;
    private double Saldo;
    
    // siempre tiene que haver un intermediario
    // untermediario son metodos: 
    // get (lectuta) y set (escritura)
    // METODOS:
    // Nivel de acceso | Valor de retorno | Nombre(Variables de entrada)
    //Leer datos de nuestra case

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = Nombre;
    }

    public double getSaldo() {
        return Saldo;
    }

    public void setSaldo(double saldo) {
        this.Saldo = Saldo;
    }
    
}
